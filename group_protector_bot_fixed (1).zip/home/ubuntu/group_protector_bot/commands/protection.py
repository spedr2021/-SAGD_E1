"""Commands for group protection (ban, kick, mute, etc.)."""

from telegram import Update
from telegram.constants import ChatMemberStatus
from telegram.error import BadRequest
from telegram.ext import ContextTypes

from helpers.decorators import admin_or_owner_required, bot_permission_required


@admin_or_owner_required
@bot_permission_required("can_kick_members")
async def kick_user(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Kicks a user from the group. Usage: /kick @username or /kick user_id or reply /kick"""
    chat = update.effective_chat
    user_to_action = None
    reason = "Kicked by admin."

    if update.message.reply_to_message:
        user_to_action = update.message.reply_to_message.from_user
        # Extract reason if provided after command in reply
        if len(context.args) > 0:
            reason = " ".join(context.args)
    elif len(context.args) >= 1:
        target = context.args[0]
        if target.startswith("@"):
            # Find user by username (requires user to be in chat or recently active)
            # This is less reliable; ID is better.
            # We'll rely on the user providing ID or replying for now.
            await update.message.reply_text("Kicking by username is not directly supported. Please reply to the user or use their ID.")
            return
        elif target.isdigit():
            try:
                user_id = int(target)
                member = await context.bot.get_chat_member(chat.id, user_id)
                user_to_action = member.user
                if len(context.args) > 1:
                    reason = " ".join(context.args[1:])
            except BadRequest:
                await update.message.reply_text("Could not find a user with that ID in this chat.")
                return
            except ValueError:
                 await update.message.reply_text("Invalid user ID.")
                 return
        else:
            await update.message.reply_text("Usage: /kick @username or /kick user_id or reply with /kick [reason]")
            return
    else:
        await update.message.reply_text("Usage: /kick @username or /kick user_id or reply with /kick [reason]")
        return

    if not user_to_action:
        await update.message.reply_text("Could not identify the user to kick.")
        return

    # Prevent kicking admins/owners
    member_to_kick = await context.bot.get_chat_member(chat.id, user_to_action.id)
    if member_to_kick.status in [ChatMemberStatus.ADMINISTRATOR, ChatMemberStatus.OWNER]:
        await update.message.reply_text("I cannot kick administrators or owners.")
        return

    try:
        # Kick (unban immediately after ban)
        await context.bot.ban_chat_member(chat_id=chat.id, user_id=user_to_action.id, until_date=1) # Ban for 1 second
        await context.bot.unban_chat_member(chat_id=chat.id, user_id=user_to_action.id)
        await update.message.reply_text(f"User {user_to_action.mention_html()} has been kicked. Reason: {reason}", parse_mode='HTML')
    except BadRequest as e:
        await update.message.reply_text(f"Failed to kick user: {e.message}")
    except Exception as e:
        await update.message.reply_text(f"An unexpected error occurred: {e}")


@admin_or_owner_required
@bot_permission_required("can_restrict_members") # Ban uses restrict permission
async def ban_user(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Bans a user from the group. Usage: /ban @username or /ban user_id or reply /ban"""
    chat = update.effective_chat
    user_to_action = None
    reason = "Banned by admin."

    if update.message.reply_to_message:
        user_to_action = update.message.reply_to_message.from_user
        if len(context.args) > 0:
            reason = " ".join(context.args)
    elif len(context.args) >= 1:
        target = context.args[0]
        if target.startswith("@"):
            await update.message.reply_text("Banning by username is not directly supported. Please reply to the user or use their ID.")
            return
        elif target.isdigit():
            try:
                user_id = int(target)
                # We don't need get_chat_member here, ban works even if user left
                user_to_action = await context.bot.get_chat(user_id) # Get user object for mention
                if len(context.args) > 1:
                    reason = " ".join(context.args[1:])
            except BadRequest:
                # Can still try to ban by ID even if get_chat fails
                user_id = int(target)
                user_to_action = type('obj', (object,), {'id': user_id, 'mention_html': lambda: f'User ID {user_id}'})()
                if len(context.args) > 1:
                    reason = " ".join(context.args[1:])
            except ValueError:
                 await update.message.reply_text("Invalid user ID.")
                 return
        else:
            await update.message.reply_text("Usage: /ban @username or /ban user_id or reply with /ban [reason]")
            return
    else:
        await update.message.reply_text("Usage: /ban @username or /ban user_id or reply with /ban [reason]")
        return

    if not user_to_action:
        await update.message.reply_text("Could not identify the user to ban.")
        return

    # Check if target is admin/owner *if* they are currently in the chat
    try:
        member_to_ban = await context.bot.get_chat_member(chat.id, user_to_action.id)
        if member_to_ban.status in [ChatMemberStatus.ADMINISTRATOR, ChatMemberStatus.OWNER]:
            await update.message.reply_text("I cannot ban administrators or owners.")
            return
    except BadRequest:
        # User might not be in the chat, proceed with ban
        pass

    try:
        await context.bot.ban_chat_member(chat_id=chat.id, user_id=user_to_action.id)
        await update.message.reply_text(f"User {user_to_action.mention_html()} has been banned. Reason: {reason}", parse_mode='HTML')
    except BadRequest as e:
        await update.message.reply_text(f"Failed to ban user: {e.message}")
    except Exception as e:
        await update.message.reply_text(f"An unexpected error occurred: {e}")

# Note: Mute requires can_restrict_members permission
@admin_or_owner_required
@bot_permission_required("can_restrict_members")
async def mute_user(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Mutes a user (restricts sending messages). Usage: /mute @username or /mute user_id or reply /mute"""
    chat = update.effective_chat
    user_to_action = None
    reason = "Muted by admin."

    if update.message.reply_to_message:
        user_to_action = update.message.reply_to_message.from_user
        if len(context.args) > 0:
            reason = " ".join(context.args)
    elif len(context.args) >= 1:
        target = context.args[0]
        if target.startswith("@"):
            await update.message.reply_text("Muting by username is not directly supported. Please reply to the user or use their ID.")
            return
        elif target.isdigit():
            try:
                user_id = int(target)
                member = await context.bot.get_chat_member(chat.id, user_id)
                user_to_action = member.user
                if len(context.args) > 1:
                    reason = " ".join(context.args[1:])
            except BadRequest:
                await update.message.reply_text("Could not find a user with that ID in this chat.")
                return
            except ValueError:
                 await update.message.reply_text("Invalid user ID.")
                 return
        else:
            await update.message.reply_text("Usage: /mute @username or /mute user_id or reply with /mute [reason]")
            return
    else:
        await update.message.reply_text("Usage: /mute @username or /mute user_id or reply with /mute [reason]")
        return

    if not user_to_action:
        await update.message.reply_text("Could not identify the user to mute.")
        return

    member_to_mute = await context.bot.get_chat_member(chat.id, user_to_action.id)
    if member_to_mute.status in [ChatMemberStatus.ADMINISTRATOR, ChatMemberStatus.OWNER]:
        await update.message.reply_text("I cannot mute administrators or owners.")
        return

    # Define permissions for mute (cannot send messages or media)
    permissions = chat.permissions
    permissions.can_send_messages = False
    permissions.can_send_media_messages = False
    permissions.can_send_polls = False
    permissions.can_send_other_messages = False
    permissions.can_add_web_page_previews = False
    permissions.can_change_info = False
    permissions.can_invite_users = False
    permissions.can_pin_messages = False

    try:
        await context.bot.restrict_chat_member(
            chat_id=chat.id,
            user_id=user_to_action.id,
            permissions=permissions
        )
        await update.message.reply_text(f"User {user_to_action.mention_html()} has been muted. Reason: {reason}", parse_mode='HTML')
    except BadRequest as e:
        await update.message.reply_text(f"Failed to mute user: {e.message}")
    except Exception as e:
        await update.message.reply_text(f"An unexpected error occurred: {e}")

# Add unban and unmute later




@admin_or_owner_required
@bot_permission_required("can_restrict_members") # Unban uses restrict permission
async def unban_user(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Unbans a user from the group. Usage: /unban user_id"""
    chat = update.effective_chat
    user_to_action = None

    if len(context.args) == 1 and context.args[0].isdigit():
        user_id = int(context.args[0])
        # Get user object for mention, even if banned
        try:
            user_to_action = await context.bot.get_chat(user_id)
        except BadRequest:
             # If get_chat fails for banned user, create a placeholder
             user_to_action = type("obj", (object,), {"id": user_id, "mention_html": lambda: f"User ID {user_id}"})()
    else:
        await update.message.reply_text("Usage: /unban user_id")
        return

    try:
        await context.bot.unban_chat_member(chat_id=chat.id, user_id=user_to_action.id)
        await update.message.reply_text(f"User {user_to_action.mention_html()} has been unbanned.", parse_mode="HTML")
    except BadRequest as e:
        await update.message.reply_text(f"Failed to unban user: {e.message}. Are they actually banned?")
    except Exception as e:
        await update.message.reply_text(f"An unexpected error occurred: {e}")


@admin_or_owner_required
@bot_permission_required("can_restrict_members")
async def unmute_user(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Unmutes a user (restores default permissions). Usage: /unmute @username or /unmute user_id or reply /unmute"""
    chat = update.effective_chat
    user_to_action = None

    if update.message.reply_to_message:
        user_to_action = update.message.reply_to_message.from_user
    elif len(context.args) == 1:
        target = context.args[0]
        if target.startswith("@"):
            await update.message.reply_text("Unmuting by username is not directly supported. Please reply to the user or use their ID.")
            return
        elif target.isdigit():
            try:
                user_id = int(target)
                member = await context.bot.get_chat_member(chat.id, user_id)
                user_to_action = member.user
            except BadRequest:
                await update.message.reply_text("Could not find a user with that ID in this chat.")
                return
            except ValueError:
                 await update.message.reply_text("Invalid user ID.")
                 return
        else:
            await update.message.reply_text("Usage: /unmute @username or /unmute user_id or reply with /unmute")
            return
    else:
        await update.message.reply_text("Usage: /unmute @username or /unmute user_id or reply with /unmute")
        return

    if not user_to_action:
        await update.message.reply_text("Could not identify the user to unmute.")
        return

    # Restore default group permissions
    # Note: We get the *chat's* default permissions, not the user's current ones
    chat_info = await context.bot.get_chat(chat.id)
    permissions = chat_info.permissions

    try:
        await context.bot.restrict_chat_member(
            chat_id=chat.id,
            user_id=user_to_action.id,
            permissions=permissions
        )
        await update.message.reply_text(f"User {user_to_action.mention_html()} has been unmuted.", parse_mode="HTML")
    except BadRequest as e:
        await update.message.reply_text(f"Failed to unmute user: {e.message}")
    except Exception as e:
        await update.message.reply_text(f"An unexpected error occurred: {e}")

