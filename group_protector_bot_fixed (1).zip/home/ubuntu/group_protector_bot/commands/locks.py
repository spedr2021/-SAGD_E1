"""Commands and handlers for locking features like links, forwards, bots, media."""

from telegram import Update
from telegram.ext import ContextTypes
from telegram.constants import ChatMemberStatus
from telegram.error import BadRequest

from helpers.decorators import admin_or_owner_required, bot_permission_required

# In-memory storage for lock states (chat_id -> {lock_type: boolean})
# IMPORTANT: This state is lost when the bot restarts.
# A persistent storage (DB or file) is needed for production use.
chat_locks = {}

# Helper to get lock status
def get_lock_status(chat_id: int, lock_type: str) -> bool:
    """Checks if a specific lock type is enabled for a chat."""
    return chat_locks.get(chat_id, {}).get(lock_type, False) # Default to False (unlocked)

# Helper to set lock status
def set_lock_status(chat_id: int, lock_type: str, status: bool):
    """Sets the status of a specific lock type for a chat."""
    if chat_id not in chat_locks:
        chat_locks[chat_id] = {}
    chat_locks[chat_id][lock_type] = status
    print(f"[Lock Update] Chat {chat_id}: {lock_type} set to {status}. Current locks: {chat_locks.get(chat_id)}") # Debug print

# --- Lock Commands ---

@admin_or_owner_required
async def lock_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Locks a specific feature (links, forward, bots, media, all). Usage: /lock <type>"""
    chat = update.effective_chat
    if chat.type == 'private':
        await update.message.reply_text("Lock commands only work in groups.")
        return

    chat_id = chat.id
    if not context.args or len(context.args) != 1:
        await update.message.reply_text("Usage: /lock <links|forward|bots|media|all>")
        return

    lock_type = context.args[0].lower()
    valid_locks = ["links", "forward", "bots", "media", "all"]

    if lock_type not in valid_locks:
        await update.message.reply_text(f"Invalid lock type. Use one of: {', '.join(valid_locks)}")
        return

    if lock_type == "all":
        updated_locks = []
        for l_type in valid_locks[:-1]: # Exclude 'all'
             if not get_lock_status(chat_id, l_type):
                 set_lock_status(chat_id, l_type, True)
                 updated_locks.append(l_type)
        if updated_locks:
            await update.message.reply_text(f"Locked: {', '.join(updated_locks)}.")
        else:
            await update.message.reply_text("All features were already locked.")
    else:
        if get_lock_status(chat_id, lock_type):
            await update.message.reply_text(f"{lock_type.capitalize()} is already locked.")
        else:
            set_lock_status(chat_id, lock_type, True)
            await update.message.reply_text(f"{lock_type.capitalize()} is now locked.")

@admin_or_owner_required
async def unlock_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Unlocks a specific feature. Usage: /unlock <type>"""
    chat = update.effective_chat
    if chat.type == 'private':
        await update.message.reply_text("Unlock commands only work in groups.")
        return

    chat_id = chat.id
    if not context.args or len(context.args) != 1:
        await update.message.reply_text("Usage: /unlock <links|forward|bots|media|all>")
        return

    lock_type = context.args[0].lower()
    valid_locks = ["links", "forward", "bots", "media", "all"]

    if lock_type not in valid_locks:
        await update.message.reply_text(f"Invalid unlock type. Use one of: {', '.join(valid_locks)}")
        return

    if lock_type == "all":
        unlocked_locks = []
        for l_type in valid_locks[:-1]: # Exclude 'all'
             if get_lock_status(chat_id, l_type):
                 set_lock_status(chat_id, l_type, False)
                 unlocked_locks.append(l_type)
        if unlocked_locks:
            await update.message.reply_text(f"Unlocked: {', '.join(unlocked_locks)}.")
        else:
            await update.message.reply_text("All features were already unlocked.")
    else:
        if not get_lock_status(chat_id, lock_type):
             await update.message.reply_text(f"{lock_type.capitalize()} is already unlocked.")
        else:
            set_lock_status(chat_id, lock_type, False)
            await update.message.reply_text(f"{lock_type.capitalize()} is now unlocked.")

# --- Message Handlers for Locks ---

# Need bot permission to delete messages
# This handler will process messages for links, forwards, and media locks
@bot_permission_required("can_delete_messages")
async def handle_message_locks(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handles incoming messages to enforce locks (links, forward, media)."""
    message = update.effective_message
    chat = update.effective_chat
    user = update.effective_user

    # Ignore if no message, chat, user, or if it's a private chat
    if not message or not chat or not user or chat.type == 'private':
        return

    # Ignore commands
    if message.text and message.text.startswith('/'):
        return

    # Check if user is admin or owner - they are immune
    try:
        member = await context.bot.get_chat_member(chat.id, user.id)
        if member.status in [ChatMemberStatus.ADMINISTRATOR, ChatMemberStatus.OWNER]:
            return
    except BadRequest as e:
        # Handle cases where user might have left between message and check
        print(f"Could not get chat member {user.id} in {chat.id}: {e}")
        return # Assume not admin if check fails
    except Exception as e:
        print(f"Unexpected error checking member status {user.id} in {chat.id}: {e}")
        return

    deleted = False
    warning_message = None

    # Check Links Lock
    if not deleted and get_lock_status(chat.id, "links"):
        has_link = False
        # Check text/caption entities first (more reliable)
        entities = message.entities or []
        caption_entities = message.caption_entities or []
        for entity in entities + caption_entities:
            if entity.type in ["url", "text_link"]:
                has_link = True
                break
        # Fallback check for plain text links if no entities found
        if not has_link:
            text_content = (message.text or "") + (message.caption or "")
            if "http://" in text_content or "https://" in text_content or "t.me/" in text_content:
                has_link = True

        if has_link:
            warning_message = f"{user.mention_html()}, sending links is forbidden here."
            deleted = True

    # Check Forward Lock
    if not deleted and get_lock_status(chat.id, "forward") and message.forward_date:
        warning_message = f"{user.mention_html()}, forwarding messages is forbidden here."
        deleted = True

    # Check Media Lock
    if not deleted and get_lock_status(chat.id, "media"):
        is_media = (
            message.photo or message.video or message.audio or message.document or
            message.sticker or message.animation or message.voice or message.video_note
        )
        if is_media:
            warning_message = f"{user.mention_html()}, sending media is forbidden here."
            deleted = True

    # Perform deletion if needed
    if deleted:
        try:
            await message.delete()
            print(f"[Lock Action] Deleted message {message.id} from {user.id} in chat {chat.id} due to lock.")
            # Optionally send a temporary warning message (can be spammy)
            # if warning_message:
            #    sent_warning = await context.bot.send_message(chat.id, warning_message, parse_mode='HTML')
            #    # Consider deleting the warning after a few seconds
            #    # await asyncio.sleep(5)
            #    # await sent_warning.delete()
        except BadRequest as e:
            # Bot might lack delete permission, or message already deleted
            print(f"Failed to delete message {message.id} in chat {chat.id}: {e}")
        except Exception as e:
            print(f"Unexpected error deleting message {message.id} in chat {chat.id}: {e}")


# Need bot permission to kick members
# This handler processes new members for the anti-bot lock
@bot_permission_required("can_kick_members")
async def handle_new_members(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handles new members joining to enforce anti-bot lock."""
    message = update.effective_message # The message announcing the new members
    chat = update.effective_chat
    new_members = message.new_chat_members

    if not chat or not new_members or chat.type == 'private':
        return

    if get_lock_status(chat.id, "bots"):
        bot_kicked = False
        for member in new_members:
            if member.is_bot and member.id != context.bot.id: # Don't kick self
                try:
                    # Kick = ban for 1 sec, then unban
                    await context.bot.ban_chat_member(chat_id=chat.id, user_id=member.id, until_date=1)
                    await context.bot.unban_chat_member(chat_id=chat.id, user_id=member.id)
                    print(f"[Lock Action] Kicked bot {member.username or member.id} from chat {chat.id}")
                    bot_kicked = True
                except BadRequest as e:
                    # Bot might lack permission or target might be admin
                    print(f"Failed to kick bot {member.id} in chat {chat.id}: {e}")
                except Exception as e:
                    print(f"Unexpected error kicking bot {member.id} in chat {chat.id}: {e}")
        # Optionally notify about the kick (can be spammy)
        # if bot_kicked:
        #    await message.reply_text("Detected and kicked a bot.")

