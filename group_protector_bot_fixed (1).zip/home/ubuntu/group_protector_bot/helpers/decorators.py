from functools import wraps
from telegram import Update
from telegram.constants import ChatMemberStatus
from telegram.ext import ContextTypes
import config

# Decorator to check if the user issuing the command is an admin or owner or the bot owner
def admin_or_owner_required(func):
    @wraps(func)
    async def wrapped(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
        user_id = update.effective_user.id
        chat = update.effective_chat

        if chat.type == 'private':
            # Allow bot owner in private chat
            if config.OWNER_ID and user_id == config.OWNER_ID:
                 return await func(update, context, *args, **kwargs)
            else:
                 await update.message.reply_text("This command requires admin privileges in a group.")
                 return

        # Check if user is the bot owner
        if config.OWNER_ID and user_id == config.OWNER_ID:
            return await func(update, context, *args, **kwargs)

        # Check if user is admin or creator in the group
        member = await context.bot.get_chat_member(chat.id, user_id)
        if member.status not in [ChatMemberStatus.ADMINISTRATOR, ChatMemberStatus.OWNER]:
            await update.message.reply_text("You need to be an admin or the bot owner to use this command.")
            return

        return await func(update, context, *args, **kwargs)
    return wrapped

# Decorator to check if the bot has specific permissions
def bot_permission_required(permission: str):
    def decorator(func):
        @wraps(func)
        async def wrapped(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
            chat = update.effective_chat
            if chat.type == 'private':
                 # Permissions don't apply in private chats
                 return await func(update, context, *args, **kwargs)

            bot_member = await context.bot.get_chat_member(chat.id, context.bot.id)

            if not getattr(bot_member, permission, False):
                 permission_name = permission.replace('can_', '').replace('_', ' ')
                 await update.message.reply_text(f"I need the '{permission_name}' permission to perform this action.")
                 return

            return await func(update, context, *args, **kwargs)
        return wrapped
    return decorator

