# Bot Configuration
BOT_TOKEN = "7998502965:AAFLzD6uQA6VBnFG5fmoU1rEh0RTyWX6OuY"
OWNER_USERNAME = "@Abds2199"
CHANNEL_USERNAME = "@SAGD_E1"

# You might need the owner's user ID as well for some checks.
# We can get this later or ask the user if needed.
OWNER_ID = None # Placeholder - Will need to fetch this or ask the user

# Database (optional, for storing settings per chat, etc.)
DATABASE_URL = None # Example: "sqlite:///protection_bot.db"

# Other settings
LOG_CHANNEL_ID = None # Optional: Channel ID for logging bot actions

